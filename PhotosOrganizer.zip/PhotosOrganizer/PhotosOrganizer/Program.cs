﻿using System.IO.Compression;
using System.Linq;

var arguments = getArguments();
var source = arguments["s"];
var dest = arguments["d"];
var dup = arguments["dup"];

var dirs = TraverseTree(source);

if (dirs.Count <= 0)
    return;

dirs.ToList().AsParallel().ForAll(dir => processfiles(dir,dest,dup));

Dictionary<string,string> getArguments()
{
   return String.Join(" ",Environment.GetCommandLineArgs().Skip(1))
        .Split('-').Where(x => !string.IsNullOrEmpty(x))
        .Select(y => new KeyValuePair<string,string>(y.Split(" ")[0], y.Split(" ")[1]))
        .ToDictionary(t => t.Key, t => t.Value);
}

void processfiles(string currentDir,string dest, string dup)
{
    var fileFilters = new String[] { "jpg", "jpeg", "png", "gif", "tiff", "bmp", "svg", "tif", "raw","mov","HEIC" };
    string[] files = null;
    try
    {
        files = System.IO.Directory.GetFiles(currentDir, string.Format("*.{0}", fileFilters),
            SearchOption.TopDirectoryOnly);
    }

    catch (UnauthorizedAccessException e)
    {

        Console.WriteLine(e.Message);
    
    }

    catch (System.IO.DirectoryNotFoundException e)
    {
        Console.WriteLine(e.Message);
        
    }catch(Exception ex)
    {
        Console.WriteLine(ex.Message);
    }
    // Perform the required action on each file here.
    // Modify this block to perform your required task.
    foreach (string file in files)
    {
        try
        {
            // Perform whatever action is required in your scenario.
            FileInfo si = new FileInfo(file);
            Console.WriteLine("{0}: {1}, {2}", si.Name, si.Length, si.CreationTime);
            var year = si.CreationTime.Year.ToString();
            var month = si.CreationTime.ToString("MMMM");
            var day = si.CreationTime.Day.ToString();

            var destPath = Path.Combine(dest, year, month, day);
            if (!(Directory.Exists(destPath)))
                Directory.CreateDirectory(destPath);

            if (!Directory.Exists(destPath))
                throw new Exception($"Unable to create directory {destPath}");

            var fileName = Path.GetFileName(file);
            var destFile = Path.Combine(destPath, fileName);

            if (File.Exists(destFile))
            {
                FileInfo di = new FileInfo(destFile);
                if (di.CreationTime.Equals(si.CreationTime))
                {
                    var dupPath = Path.Combine(dup, year, month, day);
                    if (!Directory.Exists(dupPath))
                        Directory.CreateDirectory(dupPath);

                    if (!Directory.Exists(dupPath))
                        throw new Exception($"Unable to create dup directory {dupPath}");

                    var count = 1;
                    var dupFile = Path.Combine(dupPath, fileName);
                    while(File.Exists(Path.Combine(dupFile)))
                    {
                        var f = Path.GetFileNameWithoutExtension(dupFile);
                        var ext = Path.GetExtension(dupFile);
                        dupFile = Path.Combine(dupPath, f + "_" + count++.ToString() + ext);
                    }

                    File.Move(file, dupFile);
                    
                }else
                {
                    var count = 1;
                    while (File.Exists(Path.Combine(destFile)))
                    {
                        var f = Path.GetFileNameWithoutExtension(destFile);
                        var ext = Path.GetExtension(destFile);
                        destFile = Path.Combine(destFile, f + "_" + count++.ToString() + ext);
                    }
                    File.Move(file, destFile);
                }

            } else
            {
                File.Move(file, destFile);
            }


        }
        catch (System.IO.FileNotFoundException e)
        {
            // If file was deleted by a separate application
            //  or thread since the call to TraverseTree()
            // then just continue.
            Console.WriteLine(e.Message);
            continue;
        }
    }
}

Stack<string> TraverseTree(string root)
{
    // Data structure to hold names of subfolders to be
    // examined for files.
    Stack<string> dirs = new Stack<string>(20);
    Stack<string> output = new Stack<string>();

    if (!System.IO.Directory.Exists(root))
    {
        throw new ArgumentException();
    }
    dirs.Push(root);
    output.Push(root);

    while (dirs.Count > 0)
    {
        string currentDir = dirs.Pop();
        string[] subDirs = null;
        try
        {
            subDirs = System.IO.Directory.GetDirectories(currentDir);
        }
        catch (UnauthorizedAccessException e)
        {
            Console.WriteLine(e.Message);
            continue;
        }
        catch (System.IO.DirectoryNotFoundException e)
        {
            Console.WriteLine(e.Message);
            continue;
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }

        if (subDirs == null)
            continue;

        // Push the subdirectories onto the stack for traversal.
        // This could also be done before handing the files.
        foreach (string str in subDirs)
        {
            dirs.Push(str);
            output.Push(str);
        }

    }
    return output;
}


